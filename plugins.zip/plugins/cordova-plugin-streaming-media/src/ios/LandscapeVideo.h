#import <Foundation/Foundation.h>
#import <AVKit/AVKit.h>

@interface LandscapeAVPlayerViewController: AVPlayerViewController
{
    
}
@end
